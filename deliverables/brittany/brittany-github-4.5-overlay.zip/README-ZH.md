布列塔尼议会：174项国策、100席议会、两条军事路线及专属美术。

只用于 GitHub main 4.5.0（80c4582）的独立版。保存并关闭游戏后解压，在此目录执行：

```powershell
python install.py --target "你的文档目录/Paradox Interactive/Hearts of Iron IV/mod/shadows_of_france_unification"
```

安装前核验120个文件的基线或目标哈希，拒绝覆盖并发修改。自动生成可恢复备份并保留其他运行文件及模组描述。已经安装本补丁可重复运行。不能直接用于本地4.6.0，后者有单独的分层安装回执。

已完成脚本、素材和安装夹具检查；原生引擎、真实旧档迁移和长期平衡尚未实测。
